Readme

About:
This application creates a 3D flat plane that will be used for procedural
terrain generation. The user can choose to keep applying a Diamond-Square
algorithm to generate the terrain or to apply a smoothing algorithm instead.
The smoothing algorithm also calculates the new normals. There is a maximum
number of times the Diamond-Square algorithm can be applied.

Controls:
WASD 		-> Move the Camera along first person axes
Arrow Keys 	-> Rotate the Camera
E		-> Fly the Camera directly up
Q		-> Fly the Camera directly down
Esc		-> Quit the application

[1] 		-> Apply the next step of the Diamond-Square algorithm
[2] 		-> Apply the smoothing algorithm to the terrain. Also 
		   calculate the new normals for the terrain
[3]		-> Resets the terrain to a flat plane

Know Bugs:
None

Author:
Callan Moore
MDS

Release Date:
October 20th 2015
