About:
Small application in DX 10 that renders a grid with a randomly generated Y position and changes 
color based on time. The user can control a first person camera to move around the terrain.

Controls:
[W]	-> Move the camera foward in the direction the camera is facing ( excluding Y axis changes)
[D]	-> Move the camera backwards in the opposite direction the camera is facing ( excluding Y 
		axis changes)
[A]	-> Strafe to the Left
[D]	-> Strafe to the Right

[E]	-> Fly up
[Q] 	-> Fly down

Mouse
[Horizontal Movement]	-> Turn in the direction of movement
[Vertical Movement]	-> Look up or down in the direction of movement ( Pitch)

[Esc]	-> Quit the application
[F1]	-> Toggle fullscreen mode
[F2]	-> Toggle wireframe mode

Author:
Callan Moore
MDS
