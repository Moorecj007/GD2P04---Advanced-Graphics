Readme

About:
This application creates an environment in DX10. Inside this environment
stars are rendered in the sky using a geometry shader from single points.

Controls:
WASD 		-> Move the Camera along first person axes
Arrow Keys 	-> Rotate the Camera
E		-> Fly the Camera directly up
Q		-> Fly the Camera directly down
Esc		-> Quit the application

Know Bugs:
None

Author:
Callan Moore
MDS

Release Date:
October 2nd 2015

Notes:
Look Up
