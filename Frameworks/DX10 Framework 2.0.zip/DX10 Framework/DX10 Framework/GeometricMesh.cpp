#include "GeometricMesh.h"


CGeometricMesh::CGeometricMesh()
{
}


CGeometricMesh::~CGeometricMesh()
{
}


