/*
* Bachelor of Software Engineering
* Media Design School
* Auckland
* New Zealand
*
* (c) 2005 - 2015 Media Design School
*
* File Name : GDI_Renderer.h
* Description : A renderer using GDI for 2D graphics
* Author :	Callan Moore
* Mail :	Callan.Moore@mediadesign.school.nz
*/

// Inclusion Guards
#pragma once
#ifndef __GDI_RENDERER_H__
#define __GDI_RENDERER_H__

#pragma once
class CGDI_Renderer
{
public:

	/***********************
	* CGDI_Renderer: Default Constructor for GDI Renderer class
	* @author: Callan Moore
	********************/
	CGDI_Renderer();

	/***********************
	* ~CGDI_Renderer: Default Destructor for GDI Renderer class
	* @author: Callan Moore
	********************/
	~CGDI_Renderer();

private:

};

#endif // __GDI_RENDERER_H__

