/*
* Bachelor of Software Engineering
* Media Design School
* Auckland
* New Zealand
*
* (c) 2005 - 2015 Media Design School
*
* File Name : Mesh.h
* Description : Declarations for the functions of the Mesh class
* Author :	Callan Moore
* Mail :	Callan.Moore@mediadesign.school.nz
*/

#pragma once

#ifndef __MESH_H__
#define __MESH_H__

// Library Includes 
#include <d3dx9.h>
#include <vector>

// Local Includes
#include "IRenderer.h"
#include "Vertex.h"

using namespace std;

class CMesh
{
public:
	// Constructors / Destructors
	CMesh(CIRenderer* _pRenderer);
	~CMesh();

	// Setters
	void SetPrimitiveType(eIGPrimitiveType _primType);

	//Prototypes
	void AddVertex(CVertex _vert);
	void AddIndices(std::vector<int> _vecIndices);
	void CreateStaticBuffer();
	void Draw();

protected:
	// Member Variables
	CIRenderer* m_pRenderer;
	int m_iBufferID;
	vector<CVertex> m_vecVertices;
	vector<int> m_vecIndices;
	eIGPrimitiveType m_primitiveType;
};

#endif // __MESH_H__ 