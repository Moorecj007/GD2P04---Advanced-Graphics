/*
* Bachelor of Software Engineering
* Media Design School
* Auckland
* New Zealand
*
* (c) 2005 - 2015 Media Design School
*
* File Name : 3DObject.h
* Description : Declarations for the functions of the 3D Object class
* Author :	Callan Moore
* Mail :	Callan.Moore@mediadesign.school.nz
*/

#pragma once

#ifndef __C3DOBJECT_H__
#define __C3DOBJECT_H__

// Library Includes
#include <d3dx9.h>

// Local Includes
#include "Mesh.h"
#include "Clock.h"
#include "IRenderer.h"

class C3DObject
{
public:
	// Constructors / Destructors
	C3DObject();
	~C3DObject();
	
	// Getters
	float GetYawRevolution();
	float GetPitchRevolution();
	float GetRollRevolution();

	// Setters
	void SetMesh(CMesh* _pMesh);
	void SetYaw(float _f);
	void SetPitch(float _f);
	void SetRoll(float _f);
	void SetYawRevolution(float _f);
	void SetPitchRevolution(float _f);
	void SetRollRevolution(float _f);
	void SetX(float _f);
	void SetY(float _f);
	void SetZ(float _f);

	// Prototypes
	void Initialise(CMesh* _pMesh, float _fX = 0, float _fY = 0, float _fZ = 0);
	void Draw(CIRenderer* _pRenderer);
	void Process(float _fDT);

protected:
	void CalcWorldMatrix(CIRenderer* _pRenderer);

protected:
	// Member Variables
	CMesh* m_pMesh;
	CClock* m_pClock;

	D3DXMATRIX m_matWorld;
	float m_fRotationYaw;
	float m_fRotationPitch;
	float m_fRotationRoll;

	float m_fYawRevolution;
	float m_fPitchRevolution;
	float m_fRollRevolution;

	float m_fX;
	float m_fY;
	float m_fZ;

	float m_fDT;
};

#endif // __C3DOBJECT_H__ 