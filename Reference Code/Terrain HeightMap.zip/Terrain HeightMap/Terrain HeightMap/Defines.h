/*
* Bachelor of Software Engineering
* Media Design School
* Auckland
* New Zealand
*
* (c) 2005 - 2015 Media Design School
*
* File Name : Defines.h
* Description : Declaration file to holds structs, enums and various containers/variables to be shared
* Author :	Callan Moore
* Mail :	Callan.Moore@mediadesign.school.nz
*/

#pragma once

#if !defined(__DEFINES_H__)
#define __DEFINES_H__

// Library Includes
#pragma comment(lib, "Winmm.lib")
#pragma comment(lib, "d3d9.lib")
#pragma comment(lib, "d3dx9.lib")

#include <windows.h>
#include <d3dx9.h>

// Types
typedef long VertexType;

// Enumerators
enum eIGPrimitiveType
{
	INVALID_IGPT,
	IGPT_POINTLIST,
	IGPT_LINELIST,
	IGPT_LINESTRIP,
	IGPT_TRIANGLELIST,
	IGPT_TRIANGLESTRIP,
	IGPT_TRIANGLEFAN
};

enum eIGIndexType
{
	IGIT_NONE,
	IGIT_16,
	IGIT_32
};

struct VertexScalar
{
	float Width;	// X
	float Height;	// Y
	float Depth;	// Z
};

#define VALIDATE(a) if (!a) return (false)

#endif //__DEFINES_H__
