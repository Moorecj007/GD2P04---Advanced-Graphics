/*
* Bachelor of Software Engineering
* Media Design School
* Auckland
* New Zealand
*
* (c) 2005 - 2015 Media Design School
*
* File Name : 3DObject.cpp
* Description : Implementation for the functions of the 3DObject class
* Author :	Callan Moore
* Mail :	Callan.Moore@mediadesign.school.nz
*/

// Local Includes
#include "C3DObject.h"

/***********************
* C3DObject: Default Contructor for 3DObject class
* @author: Callan Moore
********************/
C3DObject::C3DObject()
{
	m_pMesh = 0;
	m_fX = 0;
	m_fY = 0;
	m_fZ = 0;
	m_fRotationYaw = 0;
	m_fRotationPitch = 0;
	m_fRotationRoll = 0;
	m_fYawRevolution = 0;
	m_fPitchRevolution = 0;
	m_fRollRevolution = 0;
}

/***********************
* ~C3DObject: Default Destructor for 3DObject class
* @author: Callan Moore
********************/
C3DObject::~C3DObject()
{
}

/***********************
* GetYawRevolution: Retrieves the Yaw Revolution for the 3D Object
* @author: Callan Moore
* @return: float: The Yaw Revolution
********************/
float C3DObject::GetYawRevolution()
{
	return m_fYawRevolution;
}

/***********************
* GetPitchRevolution: Retrieves the Pitch Revolution for the 3D Object
* @author: Callan Moore
* @return: float: The Pitch Revolution
********************/
float C3DObject::GetPitchRevolution()
{
	return m_fPitchRevolution;
}

/***********************
* GetRollRevolution: Retrieves the Roll Revolution for the 3D Object
* @author: Callan Moore
* @return: float: The Roll Revolution 
********************/
float C3DObject::GetRollRevolution()
{
	return m_fRollRevolution;
}

/***********************
* SetMesh: Sets a new Mesh for the 3D Object
* @author: Callan Moore
* @parameter: _pMesh: Pointer to a new mesh for the 3D Object
* @return: void
********************/
void C3DObject::SetMesh(CMesh* _pMesh)
{
	m_pMesh = _pMesh;
}

/***********************
* SetYaw: Sets the Yaw component for the 3D Object
* @author: Callan Moore
* @parameter: _fYaw: New Yaw componenent (Y Rotation) in degrees per second
* @return: void
********************/
void C3DObject::SetYaw(float _fYaw)
{
	m_fRotationYaw = _fYaw;
}

/***********************
* SetPitch: Sets the Pitch component for the 3D Object
* @author: Callan Moore
* @parameter: _fPitch: New Pitch componenent (X Rotation) in degrees per second
* @return: void
********************/
void C3DObject::SetPitch(float _fPitch)
{
	m_fRotationPitch = _fPitch;
}

/***********************
* SetRoll: Sets the Roll component for the 3D Object
* @author: Callan Moore
* @parameter: _fRoll: New Roll componenent (Z Rotation) in degrees per second
* @return: void
********************/
void C3DObject::SetRoll(float _fRoll)
{
	m_fRotationRoll = _fRoll;
}

/***********************
* SetYawRevolution: Sets the Yaw Revolution for the 3D Object
* @author: Callan Moore
* @parameter: _fYaw: New Yaw Revolution (Y Rotation)
* @return: void
********************/
void C3DObject::SetYawRevolution(float _fYaw)
{
	m_fYawRevolution = _fYaw;
}

/***********************
* SetPitchRevolution: Sets the Pitch Revolution for the 3D Object
* @author: Callan Moore
* @parameter: _fPitch: New Pitch Revolution (X Rotation)
* @return: void
********************/
void C3DObject::SetPitchRevolution(float _fPitch)
{
	m_fPitchRevolution = _fPitch;
}

/***********************
* SetRollRevolution: Sets the Roll Revolution for the 3D Object
* @author: Callan Moore
* @parameter: _fRoll: New Roll Revolution (Z Rotation)
* @return: void
********************/
void C3DObject::SetRollRevolution(float _fRoll)
{
	m_fRollRevolution = _fRoll;
}

/***********************
* SetX: Sets the X component for the 3D Object
* @author: Callan Moore
* @parameter: _fX: New X componenent
* @return: void
********************/
void C3DObject::SetX(float _fX)
{
	m_fX = _fX;
}

/***********************
* SetY: Sets the Y component for the 3D Object
* @author: Callan Moore
* @parameter: _fY: New Y componenent
* @return: void
********************/
void C3DObject::SetY(float _fY)
{
	m_fY = _fY;
}

/***********************
* SetZ: Sets the Z component for the 3D Object
* @author: Callan Moore
* @parameter: _fZ: New Z componenent
* @return: void
********************/
void C3DObject::SetZ(float _fZ)
{
	m_fZ = _fZ;
}

/***********************
* C3DObject: Contructor for 3DObject class
* @author: Callan Moore
* @parameter: _pMesh: Mesh for this 3D Object
* @parameter: _fX: Starting X coordinate. Default to 0 if not specified
* @parameter: _fY: Starting Y coordinate. Default to 0 if not specified
* @parameter: _fZ: Starting Z coordinate. Default to 0 if not specified
* @return: void
********************/
void C3DObject::Initialise(CMesh* _pMesh, float _fX, float _fY, float _fZ)
{
	m_pMesh = _pMesh;
	m_fX = _fX;
	m_fY = _fY;
	m_fZ = _fZ;
}

/***********************
* Draw: Draws the 3D Object
* @author: Callan Moore
* @parameter: _pRenderer: Renderer for this application
* @return: void
********************/
void C3DObject::Draw(CIRenderer* _pRenderer)
{
	// Calculates the World Matrix for this 3D Object
	CalcWorldMatrix(_pRenderer);
	m_pMesh->Draw();
}

/***********************
* Process: Processes the 3D Object for the Delta tick
* @author: Callan Moore
* @parameter: _fDT: The Delta Tick
* @return: void
********************/
void C3DObject::Process(float _fDT)
{
	m_fDT = _fDT;
}

/***********************
* CalcWorldMatrix: Calculates the World Matrix for this Object
* @author: Callan Moore
* @parameter: _pRenderer: Renderer for this application
* @return: void
********************/
void C3DObject::CalcWorldMatrix(CIRenderer* _pRenderer)
{
	// Matrices to make up the World Matrix
	D3DXMATRIX matRotateX;   
	D3DXMATRIX matRotateY;
	D3DXMATRIX matRotateZ;
	D3DXMATRIX matTranslation;
	D3DXMATRIX matWorld;

	// Increases the rotation by the Objects corresponding increment value
	m_fRotationPitch += (m_fPitchRevolution * m_fDT);
	m_fRotationYaw += (m_fYawRevolution * m_fDT);
	m_fRotationRoll += (m_fRollRevolution * m_fDT);

    // Create Rotational Matrices for this Object based on its starting Yaw/Pitch/Roll and the increments
	D3DXMatrixRotationX(&matRotateX, m_fRotationPitch);
    D3DXMatrixRotationY(&matRotateY, m_fRotationYaw);
	D3DXMatrixRotationZ(&matRotateZ, m_fRotationRoll);

	// Create the Translation Matrix from the Objects Position coordinates
	D3DXMatrixTranslation(&matTranslation, m_fX, m_fY, m_fZ);
	
	matWorld = (matRotateX * matRotateY * matRotateZ * matTranslation);

    // Set The World Matrix for this Object on the Renderer
	_pRenderer->SetWorldMatrix(matWorld);
}

