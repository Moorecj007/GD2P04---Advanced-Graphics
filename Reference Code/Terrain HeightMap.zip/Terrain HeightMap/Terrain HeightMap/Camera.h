//
// Bachelor of Software Engineering
// Media Design School 
// Auckland
// New Zealand 
// 
// (c) 2005 - 2015 Media Design School 
// 
// File Name : CCamera.h
// Description : Contains the header file for CCamera Class
// Author : Jc Fowles 
// Mail : Jc.Fowles@mediadesign.school.nz 
//
#pragma once

//Include library
#include <d3d9.h>
#include <d3dx9.h>

class CCamera
{
	//member functions
public:
	//****Creation/Deletion****
	CCamera();
	~CCamera();

	//Generic Functions
	bool Initialise(float _fScreenWidth, float _fScreenHeight);
	void Process();

	//Creation
	void CreateProjectionMatrix(float fov, float aspect, float nearPlane, float farPlane);
	//void CreateViewMatrix();

	//****Getters****

	//TO DO - GetUp()

	//View Stuff
	D3DXMATRIX* GetViewMatrix();
	D3DXVECTOR3* GetPosition();
	D3DXVECTOR3* GetTarget();
	D3DXVECTOR3* GetUp();
	//Projection Stuff
	D3DXMATRIX* GetProjectionMatrix();
	float GetFOV();
	float GetAspectRatio();
	float GetNearPlane();
	float GetFarPlane();
	//Limitations
	float GetMaxVelocity();
	BOOL  GetInvertY();
	float GetMaxPitch();
	//Rotations
	float GetPitch();
	float GetYaw();
	
	//****Setters****

	//View
	void CCamera::SetViewProperties(D3DXVECTOR3& _D3DVecCamPos, D3DXVECTOR3& _D3DVecLookAt, D3DXVECTOR3& _D3DVecUp);
	void SetPostionVec(D3DXVECTOR3& _D3DVecCamPos);
	void SetTargetVec(D3DXVECTOR3& _D3DVecLookAt);
	void SetUpVec(D3DXVECTOR3& _D3DVecUp);
	//Projection
	void SetFOV(float fov);//            { CreateProjectionMatrix(fov, m_aspect, m_nearPlane, m_farPlane); }
	void SetAspectRatio(float aspect);// { CreateProjectionMatrix(m_fov, aspect, m_nearPlane, m_farPlane); }
	void SetNearPlane(float plane);//    { CreateProjectionMatrix(m_fov, m_aspect, plane, m_farPlane); }
	void SetFarPlane(float plane);//    { CreateProjectionMatrix(m_fov, m_aspect, m_nearPlane, plane); }
	//Limitations
	void SetMaxVelocity(float maxVelocity);// { m_maxVelocity = maxVelocity; }
	void SetMaxPitch(float maxPitch);//      { m_maxPitch = maxPitch; }
	
	void SetInvertY(BOOL invert);//          { m_invertY = invert; }
		
	//****Functionality****
	
	//Rotations
	void Pitch(float _fDeg);	//X-Axis
	void Yaw(float _fDeg);		//Y-Axis
	void Roll(float _fDeg);		//Z-Axis

	//Movements
	void Strafe(float _fDistance);	//X-Axis
	void Fly(float _fDistance);		//Y-Axis
	void Move(float _fDistance);	//Z-Axis
	
	
	
	//Member variables
private:
	
	//Matricis
	D3DXMATRIX  m_D3DMatView;
	D3DXMATRIX  m_D3DMatProjection;
	
	//Camera Axis
	D3DXVECTOR3 m_D3DVecRight;	//Camera Right(X-Axis)
	D3DXVECTOR3 m_D3DVecUp;		//Camera Up(Y-Axis)
	D3DXVECTOR3 m_D3DVeclook;	//Camera Look(Z-Axis)

	//Camera Properties
	D3DXVECTOR3 m_D3DVecPosition;
	D3DXVECTOR3 m_D3DVecTarget;		//Target 
	D3DXVECTOR3 m_D3DVecVelocity;	
	
	//Rotation Values
	float       m_fYaw;
	float       m_fPitch;
	float		m_fRoll;
	
	//Rotaion Limitations
	float       m_fMaxPitch;
	float       m_fMaxVelocity;

	//Projection Values
	float       m_fFOV;
	float       m_fAspect;
	float       m_fNearPlane;
	float       m_fFarPlane;
	
	//Camera Booleans
	BOOL        m_bInvertY;
	BOOL        m_bEnableYMovement;


		
};

