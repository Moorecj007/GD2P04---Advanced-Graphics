/*
* Bachelor of Software Engineering
* Media Design School
* Auckland
* New Zealand
*
* (c) 2005 - 2015 Media Design School
*
* File Name : Game.h
* Description : Declarations for the functions of the Game class
* Author :	Callan Moore
* Mail :	Callan.Moore@mediadesign.school.nz
*/

#pragma once

#ifndef __GAME_H__
#define __GAME_H__

// Local Includes
#include "IRenderer.h"
#include "D3D9Renderer.h"
#include "Clock.h"
#include "Terrain.h"
#include "Mesh.h"
#include "C3DObject.h"
#include "Camera.h"


class CGame
{
public:
	// Constructors / Destructors
	~CGame();

	//Protoypes
	void Initialise(HWND _hWnd, int _iScreenWidth, int _iScreenHeight, bool _bFullscreen);
	void RenderFrame();
	void Process();
	void Draw();

	void RenderDebugOutput();

	CMesh* CreateCubeMesh();
	C3DObject CreateCube();

	// Getters
	CCamera* GetCamera();

	// Singleton Methods
	static CGame& GetInstance();
	static void DestroyInstance();

private:
	//Disallowing copies and extra constructions
	CGame();
	CGame(const CGame& _kr);
	CGame& operator= (const CGame& _kr);

	// Singleton Instance
	static CGame* s_pGame;

private:
	// Member Variables
	CIRenderer* m_pRenderer;
	CClock* m_pClock;
	CTerrain* m_pTerrain;
	CCamera* m_pCamera;

	CMesh* m_pCubeMesh;
	C3DObject Cube1;

	// Frame Counting
	int m_iFrameTimeStart;
	int m_iFrameTimeEnd;
	int m_iFrameTimeDifference;

	int m_iSecondCounter;
	int m_iFrameCounter;
	int m_iFPS;

};

#endif //__GAME_H__


