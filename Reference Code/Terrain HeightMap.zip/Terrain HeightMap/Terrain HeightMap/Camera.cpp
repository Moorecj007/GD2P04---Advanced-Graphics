//
// Bachelor of Software Engineering
// Media Design School 
// Auckland
// New Zealand 
// 
// (c) 2005 - 2015 Media Design School 
// 
// File Name : CCamera.cpp
// Description : Contains the main funtionality of CCamera Class
// Author : Jc Fowles 
// Mail : Jc.Fowles@mediadesign.school.nz 
//

//This include
#include "Camera.h"

/***********************
* CCamera: Constructor of the CCamera object
* @author: Jc Fowles
* @return:
********************/
CCamera::CCamera()
{
	
}

/***********************
* CCamera: Destructor of the CCamera object
* @author: Jc Fowles
* @return:
********************/
CCamera::~CCamera()
{

}

/***********************
* SetPostionVec: Set the Position vector
* @author: Jc Fowles
* @return: bool: Successful Initialisation or not
********************/
bool CCamera::Initialise(float _fScreenWidth, float _fScreenHeight)
{
	//TO DO

	m_fMaxPitch = (89.0f);
	m_fMaxVelocity = 1000.0f;
	m_bInvertY = FALSE;
	m_bEnableYMovement = TRUE;

	m_D3DVecPosition = D3DXVECTOR3(0.0f, 500.0f, -500.0f);
	m_D3DVecTarget = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
	m_D3DVecUp = D3DXVECTOR3(0.0f, 1.0f, 0.0f);
	m_D3DVeclook = D3DXVECTOR3(0.0f, -1.0f, 1.0f);

	//m_D3DVecPosition = D3DXVECTOR3(0.0f, 0.0f, -10.0f);
	//m_D3DVecTarget = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
	//m_D3DVecUp = D3DXVECTOR3(0.0f, 1.0f, 0.0f);
	//m_D3DVeclook = D3DXVECTOR3(0.0f, 0.0f, 1.0f);
	
	m_D3DVecVelocity = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
	
	float fAspectRatio = (_fScreenWidth / _fScreenHeight);
	CreateProjectionMatrix(D3DXToRadian(45), fAspectRatio, 0.1f, 10000.0f);
	
	Process();
		
	return true;
}

/***********************
* SetViewProperties: Set the Position, LookAt/Targer and Up vector for the view matrix
* @author: Jc Fowles
* @parameter: _D3DVecCamPos: The position vector to set the camera to
* @return: void
********************/
void CCamera::SetViewProperties(D3DXVECTOR3& _D3DVecCamPos, D3DXVECTOR3& _D3DVecLookAt, D3DXVECTOR3& _D3DVecUp)
{
	m_D3DVecPosition = _D3DVecCamPos;
	m_D3DVecTarget = _D3DVecLookAt;
	m_D3DVecUp = _D3DVecUp;
}


/***********************
* process: Process the camera
* @author: Jc Fowles
* @return: void
********************/
void CCamera::Process()
{
	//TO DO
	// Cap velocity to max velocity
	if (D3DXVec3Length(&m_D3DVecVelocity) > m_fMaxVelocity)
	{
		m_D3DVecVelocity = *(D3DXVec3Normalize(&m_D3DVecVelocity, &m_D3DVecVelocity)) * m_fMaxVelocity;
	}

	//Move the camera
	m_D3DVecPosition += m_D3DVecVelocity;
	
	//Could decelerate here. I'll just stop completely.
	m_D3DVecVelocity = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
	m_D3DVecTarget = m_D3DVecPosition + m_D3DVeclook;

	//Calculate the new view matrix
	D3DXVECTOR3 up = D3DXVECTOR3(0.0f, 1.0f, 0.0f);
	D3DXMatrixLookAtLH(&m_D3DMatView, &m_D3DVecPosition, &m_D3DVecTarget, &up);

	//Set the camera axis from the view matrix
	m_D3DVecRight.x = m_D3DMatView._11;
	m_D3DVecRight.y = m_D3DMatView._21;
	m_D3DVecRight.z = m_D3DMatView._31;
	m_D3DVecUp.x = m_D3DMatView._12;
	m_D3DVecUp.y = m_D3DMatView._22;
	m_D3DVecUp.z = m_D3DMatView._32;
	m_D3DVeclook.x = m_D3DMatView._13;
	m_D3DVeclook.y = m_D3DMatView._23;
	m_D3DVeclook.z = m_D3DMatView._33;

	//Calculate yaw and pitch
	float lookLengthOnXZ = sqrtf(m_D3DVeclook.z * m_D3DVeclook.z + m_D3DVeclook.x * m_D3DVeclook.x);
	m_fYaw = D3DXToDegree(atan2f(m_D3DVeclook.y, lookLengthOnXZ)); // atan2f(m_D3DVeclook.y, lookLengthOnXZ);
	m_fPitch = D3DXToDegree(atan2f(m_D3DVeclook.x, m_D3DVeclook.z)); // atan2f(m_D3DVeclook.x, m_D3DVeclook.z);
}

/***********************
* GetViewMatrix: Get the View matrix
* @author: Jc Fowles
* @return: D3DXMATRIX*: Returns the the View Matrix
********************/
D3DXMATRIX* CCamera::GetViewMatrix()
{
	return &m_D3DMatView;
}

/***********************
* GetProjectionMatrix: Get the Projection matrix
* @author: Jc Fowles
* @return: D3DXMATRIX*: Returns the the Projection Matrix
********************/
D3DXMATRIX* CCamera::GetProjectionMatrix()
{
	return &m_D3DMatProjection;
}

/***********************
* GetPosition: Get the Position of the camera
* @author: Jc Fowles
* @return: D3DXVECTOR3*: Returns the the Position vector of the camera
********************/
D3DXVECTOR3* CCamera::GetPosition()
{ 
	return &m_D3DVecPosition;
}

/***********************
* GetLookAt: Get the target of the camera
* @author: Jc Fowles
* @return: D3DXVECTOR3*: Returns the the target vector of the camera
********************/
D3DXVECTOR3* CCamera::GetTarget()
{
	return &m_D3DVecTarget;
}

/***********************
* GetUp: Get the Up vector of the camera
* @author: Jc Fowles
* @return: D3DXVECTOR3*: Returns the the up vector of the camera
********************/
D3DXVECTOR3* CCamera::GetUp()
{
	return &m_D3DVecUp;
}

/***********************
* GetFOV: Get the Field of View of the camera
* @author: Jc Fowles
* @return: float: Returns the Field of View 
********************/
float CCamera::GetFOV()
{ 
	return m_fFOV;
}

/***********************
* GetFOV: Get the Aspect ratio
* @author: Jc Fowles
* @return: float: Returns the Aspect ratio 
********************/
float CCamera::GetAspectRatio()
{
	return m_fAspect;
}

/***********************
* GetNearPlane: Get the Near plane
* @author: Jc Fowles
* @return: float: Returns the near plane
********************/
float CCamera::GetNearPlane()
{
	return m_fNearPlane;
}

/***********************
* GetNearPlane: Get the Far plane
* @author: Jc Fowles
* @return: float: Returns the far plane
********************/
float CCamera::GetFarPlane()
{
	return m_fFarPlane; 
}

/***********************
* GetMaxVelocity: Get the Camera's Max allowed velocity
* @author: Jc Fowles
* @return: float: Returns the Camera's Max allowed velocity
********************/
float CCamera::GetMaxVelocity()
{
	return m_fMaxVelocity; 
}

/***********************
* GetMaxPitch: Return The maximum allow pitch rotation
* @author: Jc Fowles
* @return: float: Returns The maximum allow pitch rotation
********************/
float CCamera::GetMaxPitch()
{
	return m_fMaxPitch;
}

/***********************
* GetInvertY: Return if the Y-Axis has been inverted
* @author: Jc Fowles
* @return: bool: Returns if the Y-Axis has been inverted
********************/
BOOL  CCamera::GetInvertY()
{
	return m_bInvertY;
}

/***********************
* GetPitch: Return the pitch rotation in Degree
* @author: Jc Fowles
* @return: float: Returns the pitch rotation in Degree
********************/
float CCamera::GetPitch()
{
	return m_fPitch; 
}

/***********************
* GetYaw: Return the Yaw rotation in Degree
* @author: Jc Fowles
* @return: float: Returns the yaw rotation in Degree
********************/
float CCamera::GetYaw()
{
	return m_fYaw; 
}

//TO DO - maybe GetRoll()

/***********************
* SetPostionVec: Set the Position vector
* @author: Jc Fowles
* @parameter: _D3DVecCamPos: The position vector to set the camera to
* @return: void
********************/
void CCamera::SetPostionVec(D3DXVECTOR3& _D3DVecCamPos)
{
	m_D3DVecPosition = _D3DVecCamPos;
}

/***********************
* SetLookAtVec: Set the Look At vector
* @author: Jc Fowles
* @parameter: _D3DVecLookAt: The Look At vector to set the camera to
* @return: void
********************/
void CCamera::SetTargetVec(D3DXVECTOR3& _D3DVecLookAt)
{
	m_D3DVecTarget = _D3DVecLookAt;
}

/***********************
* SetUpVec: Set the Look At vector
* @author: Jc Fowles
* @parameter: _D3DVecUp: The Up vector to set the camera to
* @return: void
********************/
void CCamera::SetUpVec(D3DXVECTOR3& _D3DVecUp)
{
	m_D3DVecUp = _D3DVecUp;
}

//TO DO - Setters
void CCamera::SetFOV(float _fFov)            { CreateProjectionMatrix(_fFov, m_fAspect, m_fNearPlane, m_fFarPlane); }
void CCamera::SetAspectRatio(float _fAspect) { CreateProjectionMatrix(m_fFOV, _fAspect, m_fNearPlane, m_fFarPlane); }
void CCamera::SetNearPlane(float _fPlane)    { CreateProjectionMatrix(m_fFOV, m_fAspect, _fPlane, m_fFarPlane); }
void CCamera::SetFarPlane(float _fPlane)    { CreateProjectionMatrix(m_fFOV, m_fAspect, m_fNearPlane, _fPlane); }
void CCamera::SetMaxVelocity(float maxVelocity) { m_fMaxVelocity = maxVelocity; }
void CCamera::SetMaxPitch(float maxPitch)     { m_fMaxPitch = maxPitch; }
void CCamera::SetInvertY(BOOL invert)          { m_bInvertY = invert; }
//TO DO


/***********************
* Pitch: Rotate camera on the X-Axis 
* @author: Jc Fowles
* @parameter: _fDeg: The amount in degree you would like to rotate
* @return: void
********************/
void CCamera::Pitch(float _fDeg)
{
	//TO DO - comment
	if (_fDeg == 0.0f)
	{
		return;
	}
	
	float fRotInRads = D3DXToRadian(_fDeg);
	
	//If Y is inverted then RotInRads will be negative, and vice versa
	/* if(m_bInvertY {-fRotInRads}
	* else {fRotInRads}; */
	fRotInRads = (m_bInvertY) ? -fRotInRads : fRotInRads;
		
	m_fPitch -= fRotInRads;

	if (m_fPitch > m_fMaxPitch)
	{
		fRotInRads += m_fPitch - m_fMaxPitch;
	}
	else if (m_fPitch < -m_fMaxPitch)
	{
		fRotInRads += m_fPitch + m_fMaxPitch;
	}

	D3DXMATRIX D3DXRotation;
	D3DXMatrixRotationAxis(&D3DXRotation, &m_D3DVecRight, fRotInRads);
	D3DXVec3TransformNormal(&m_D3DVecUp, &m_D3DVecUp, &D3DXRotation);
	D3DXVec3TransformNormal(&m_D3DVeclook, &m_D3DVeclook, &D3DXRotation);
}

/***********************
* Pitch: Rotate camera on the Y-Axis
* @author: Jc Fowles
* @parameter: _fDeg: The amount in degree you would like to rotate
* @return: void
********************/
void CCamera::Yaw(float _fDeg)
{
	//TO DO - comment
	if (_fDeg == 0.0f)
	{
		return;
	}

	float fRotInRads = D3DXToRadian(_fDeg);
	D3DXMATRIX D3DXRotation;
	D3DXMatrixRotationAxis(&D3DXRotation, &m_D3DVecUp, fRotInRads);
	D3DXVec3TransformNormal(&m_D3DVecRight, &m_D3DVecRight, &D3DXRotation);
	D3DXVec3TransformNormal(&m_D3DVeclook, &m_D3DVeclook, &D3DXRotation);
}

/***********************
* Pitch: Rotate camera on the Z-Axis
* @author: Jc Fowles
* @parameter: _fDeg: The amount in degree you would like to rotate
* @return: void
********************/
void CCamera::Roll(float _fDeg)
{
	//TO DO - comment
	if (_fDeg == 0.0f)
	{
		return;
	}
	float fRotInRads = D3DXToRadian(_fDeg);
	D3DXMATRIX D3DXRotation;
	D3DXMatrixRotationAxis(&D3DXRotation, &m_D3DVeclook, fRotInRads);
	D3DXVec3TransformNormal(&m_D3DVecRight, &m_D3DVecRight, &D3DXRotation);
	D3DXVec3TransformNormal(&m_D3DVecUp, &m_D3DVecUp, &D3DXRotation);
}

/***********************
* Strafe: Move the camera on the X-Axis
* @author: Jc Fowles
* @parameter: _fDistance: The Distance you would like to move
* @return: void
********************/
void CCamera::Strafe(float _fDistance)
{
	//TO DO - comment
	m_D3DVecVelocity += m_D3DVecRight * _fDistance;
}


/***********************
* Fly: Move the camera on the Y-Axis
* @author: Jc Fowles
* @parameter: _fDistance: The Distance you would like to move
* @return: void
********************/
void CCamera::Fly(float _fDistance)
{
	//TO DO - comment
	if (m_bEnableYMovement)
	{
		m_D3DVecVelocity.y += _fDistance;
	}
}

/***********************
* Move: Move the camera on the Z-Axis
* @author: Jc Fowles
* @parameter: _fDistance: The Distance you would like to move in units per velocity
* @return: void
********************/
void CCamera::Move(float _fDistance)
{
	//TO DO - comment
	if (m_bEnableYMovement)
	{
		m_D3DVecVelocity += m_D3DVeclook * _fDistance;
	}
	else
	{
		D3DXVECTOR3 D3DMoveVector(m_D3DVeclook.x, 0.0f, m_D3DVeclook.z);
		D3DXVec3Normalize(&D3DMoveVector, &D3DMoveVector);
		D3DMoveVector *= _fDistance;
		m_D3DVecVelocity += D3DMoveVector;
	}
}

/***********************
* CreateViewMatrix: Create the View matrix
* @author: Jc Fowles
* @return: void
********************/
//void CCamera::CreateViewMatrix()
//{
//	D3DXMatrixLookAtLH(&m_D3DMatView, &m_D3DVecPosition, &m_D3DVecTarget, &m_D3DVecUp);
//}

/***********************
* CreateProjectionMatrix: Create the Projection matrix
* @author: Jc Fowles
* @parameter: _fFov: Field of view 
* @parameter: _fAspect: Aspect ratio
* @parameter: _fNearPlane: Near plane
* @parameter: _fFarPlane: Far plane
* @return: void
********************/
void CCamera::CreateProjectionMatrix(float _fFov, float _fAspect, float _fNearPlane, float _fFarPlane)
{
	m_fFOV = _fFov;
	m_fAspect = _fAspect;
	m_fNearPlane = _fNearPlane;
	m_fFarPlane = _fFarPlane;
	D3DXMatrixPerspectiveFovLH(&m_D3DMatProjection, m_fFOV, m_fAspect, m_fNearPlane, m_fFarPlane);
}