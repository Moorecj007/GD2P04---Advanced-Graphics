/*
* Bachelor of Software Engineering
* Media Design School
* Auckland
* New Zealand
*
* (c) 2005 - 2015 Media Design School
*
* File Name : Game.cpp
* Description : Implementation for the functions of the Game class
* Author :	Callan Moore
* Mail :	Callan.Moore@mediadesign.school.nz
*/

// Local Includes
#include "Game.h"

// Static Variables
CGame* CGame::s_pGame = 0;

/***********************
* Game: Default Contructor for Game class
* @author: Callan Moore
********************/
CGame::CGame()
{
	m_pRenderer = 0;
	m_pClock = 0;
	m_pTerrain = 0;
	m_pCamera = 0;

	m_iFrameTimeStart = 0;
	m_iFrameTimeEnd = 0;
	m_iFrameTimeDifference = 0;
	m_iSecondCounter = 0;
	m_iFrameCounter = 0;
}

/***********************
* ~Game: Default Destructor for Game class
* @author: Callan Moore
********************/
CGame::~CGame()
{
	// Delete allocated memory
	delete m_pRenderer;
	m_pRenderer = 0;
	delete m_pClock;
	m_pClock = 0;
	delete m_pTerrain;
	m_pTerrain = 0;
	delete m_pCamera;
	m_pCamera = 0;
	delete m_pCubeMesh;
	m_pCamera = 0;
}

/***********************
* Initialize: Initialise the Game Object for Use
* @author: Callan Moore
* @parameters: _hWnd: Handle to The creating window
* @parameters: _iScreenWidth: The Height of the Screen
* @parameters: _iScreenHeight: The Width of the Screen
* @parameters: _bFullscreen: Whether the Game will be run in Fullscreen
* @return: void
********************/
void CGame::Initialise(HWND _hWnd, int _iScreenWidth, int _iScreenHeight, bool _bFullscreen)
{
	// Create a Clock for the Game
	m_pClock = new CClock();

	// Create and inititalise the Camera for the Game
	m_pCamera = new CCamera();
	m_pCamera->Initialise((float)_iScreenWidth, (float)_iScreenHeight);

	// Create and inititalise the Renderer for the Game
	m_pRenderer = new CD3D9Renderer();
	m_pRenderer->Initialise(_iScreenWidth, _iScreenHeight, _hWnd, _bFullscreen);

	// Create the initial View and Projection Matrices and set them on the Renderer
	m_pRenderer->CreateViewMatrix(*(m_pCamera->GetPosition()), *(m_pCamera->GetTarget()), *(m_pCamera->GetUp()));
	m_pRenderer->CalculateProjectionMatrix((m_pCamera->GetFOV()), (m_pCamera->GetNearPlane()), (m_pCamera->GetFarPlane()));

	// Create a Terrain for the Game
	m_pTerrain = new CTerrain();
	VertexScalar TerrainScalar = { 5.0f, 1.0f, 5.0f };
	std::string strImagePath = "Assets\\HeightMap.bmp";
	m_pTerrain->Initialise(m_pRenderer, strImagePath, TerrainScalar);
	m_pTerrain->SetCenter(0, 0, 0);

	// TO DO - make create cube function
	// Create Mesh
	m_pCubeMesh = CreateCubeMesh();

	// Create Cube 1
	Cube1 = C3DObject();

	Cube1.Initialise(m_pCubeMesh, 0, 0, 0);					// Initialise the Cube Object with the Cube Mesh and set its coordinates
	Cube1.SetPitch(D3DXToRadian(-20));					// Set Starting Pitch/Yaw/Roll 
	Cube1.SetRoll(D3DXToRadian(-20));						// ^
	Cube1.SetYawRevolution(D3DXToRadian(36));				// Set Rotation around the Z Axis at 90 degrees per second
}

/***********************
* RenderFrame: Renders one frame
* @author: Callan Moore
* @return: void
********************/
void CGame::RenderFrame()
{
	// Snapshot Time at the beginning of the frame
	m_iFrameTimeStart = (int)timeGetTime();
	Sleep(1);

	// Process the Game
	Process();

	//Draw the Game Objects
	Draw();

	// Snapshot Time at the end of the frame
	m_iFrameTimeEnd = (int)timeGetTime();
	// Calculate the Total time taken to complete frame
	m_iFrameTimeDifference = m_iFrameTimeEnd - m_iFrameTimeStart;
	// Increase the Second Counter by the Frame difference
	m_iSecondCounter += m_iFrameTimeDifference;
	m_iFrameCounter++;	// Increment the number of frames Rendered

	// Calculate the the remaining time to render frames at 60 per Second
	int iTimeToWait;
	// Sleep function works in whole milliseconds and 1000/60 = 16.6667
	if (m_iFrameCounter % 3 == 0)
	{
		// Every third frame wait 1 millisecond less to offset the 2 frames over the 16.667 mark
		iTimeToWait = (16) - (m_iFrameTimeDifference);
	}
	else
	{
		iTimeToWait = (17) - (m_iFrameTimeDifference);
	}

	// Sleep only if the Rendering of the frame took less than 1/60 seconds
	if (iTimeToWait > 0)
	{
		Sleep(iTimeToWait);
		m_iSecondCounter += iTimeToWait;
	}

	if (m_iSecondCounter >= 1000)
	{
		m_iSecondCounter -= 1000;	// Remove one second of time from counter. Prevents integer wrap around
		m_iFPS = m_iFrameCounter;	// FPS for this second is set to the number of frames rendered
		m_iFrameCounter = 0;		// Reset the Frame counter
	}
}

/***********************
* Process: Processes the Game for the Delta tick
* @author: Callan Moore
* @return: void
********************/
void CGame::Process()
{
	m_pClock->Process();
	float fDT = m_pClock->GetDeltaTick();
	Cube1.Process(fDT);
	m_pCamera->Process();

	m_pRenderer->CreateViewMatrix(*(m_pCamera->GetPosition()), *(m_pCamera->GetTarget()), *(m_pCamera->GetUp()));
}

/***********************
* Draw: Draws all the game world
* @author: Callan Moore
* @return: void
********************/
void CGame::Draw()
{
	m_pRenderer->StartRender(true, true, false);

	Cube1.Draw(m_pRenderer);
	m_pTerrain->Draw(m_pRenderer);

	RenderDebugOutput();

	m_pRenderer->EndRender();
}

/***********************
* GetInstance: Returns the singleton instance of the game, if it doesnt exist creates it.
* @author: Callan Moore
* @return: CGame&: The current instance of the game
********************/
CGame& CGame::GetInstance()
{
	if (s_pGame == 0)
	{
		s_pGame = new CGame();
	}
	return (*s_pGame);
}

/***********************
* DestroyInstance: Deletes the instance of the game. 
* @author: Callan Moore
* @return: void
********************/
void CGame::DestroyInstance()
{
	delete s_pGame;
	s_pGame = 0;
}

/***********************
* RenderDebugOuput: Render Text to the screen for debug purposes
* @author: Callan Moore
* @return: void
********************/
void CGame::RenderDebugOutput()
{
	int iYPos = 0;
	m_pRenderer->RenderDebugOutput("Cube World Matrix", (iYPos += 20), 0xff000000);
	m_pRenderer->RenderDebugOutput("Position: xxx", (iYPos += 20), 0xff000000);
	m_pRenderer->RenderDebugOutput("LookAt:   xxx", (iYPos += 20), 0xff000000);
	m_pRenderer->RenderDebugOutput("Up:       xxx", (iYPos += 20), 0xff000000);

	(iYPos += 20);
	std::string strViewPosition = to_string((int)(m_pCamera->GetPosition()->x)) + ", " + to_string((int)(m_pCamera->GetPosition()->y)) + ", " + to_string((int)m_pCamera->GetPosition()->z);
	std::string strViewLookAt = to_string((int)(m_pCamera->GetTarget()->x)) + ", " + to_string((int)(m_pCamera->GetTarget()->y)) + ", " + to_string((int)m_pCamera->GetTarget()->z);
	std::string strViewUp = to_string((int)(m_pCamera->GetUp()->x)) + ", " + to_string((int)(m_pCamera->GetUp()->y)) + ", " + to_string((int)m_pCamera->GetUp()->z);
	m_pRenderer->RenderDebugOutput("View Matrix", (iYPos += 20), 0xff000000);
	m_pRenderer->RenderDebugOutput("Position: " + strViewPosition, (iYPos += 20), 0xff000000);
	m_pRenderer->RenderDebugOutput("LookAt:   " + strViewLookAt, (iYPos += 20), 0xff000000);
	m_pRenderer->RenderDebugOutput("Up:       " + strViewUp, (iYPos += 20), 0xff000000);
	
	(iYPos += 20);
	D3DXMATRIX matView = m_pRenderer->GetProjectionMatrix();
	strViewPosition = to_string((int)matView._11) + ", " + to_string((int)(matView._12)) + ", " + to_string((int)matView._13);
	strViewLookAt = to_string((int)(m_pCamera->GetTarget()->x)) + ", " + to_string((int)(m_pCamera->GetTarget()->y)) + ", " + to_string((int)m_pCamera->GetTarget()->z);
	strViewUp = to_string((int)(m_pCamera->GetUp()->x)) + ", " + to_string((int)(m_pCamera->GetUp()->y)) + ", " + to_string((int)m_pCamera->GetUp()->z);
	m_pRenderer->RenderDebugOutput("Projection Matrix", (iYPos += 20), 0xff000000);
	m_pRenderer->RenderDebugOutput("Position: " + strViewPosition, (iYPos += 20), 0xff000000);
	m_pRenderer->RenderDebugOutput("LookAt:   xxx", (iYPos += 20), 0xff000000);
	m_pRenderer->RenderDebugOutput("Up:       xxx", (iYPos += 20), 0xff000000);
	
	(iYPos += 20);
	m_pRenderer->RenderDebugOutput("Camera Mode: First Person", (iYPos += 20), 0xff000000);

	(iYPos += 20);
	
	m_pRenderer->RenderDebugOutput("FPS: " + to_string(m_iFPS), (iYPos += 20), 0xff000000);
}

/***********************
* CreateCubeMesh: Creates a cube Mesh with origin in its very center
* @author: Callan Moore
* @return: CMesh*: Pointer to a created Cube mesh
********************/
CMesh* CGame::CreateCubeMesh()
{
	// TO DO - Comment
	float fVertexfromOrigin = 1.0f;
	CMesh* meshCube = new CMesh(m_pRenderer);
	
	D3DVECTOR normal = { -1.0f, 1.0f, -1.0f };
	meshCube->AddVertex(CVertex(-fVertexfromOrigin, fVertexfromOrigin, -fVertexfromOrigin,-1.0f, 1.0f, -1.0f));
	normal = { 1.0f, 1.0f, -1.0f };
	meshCube->AddVertex(CVertex(fVertexfromOrigin, fVertexfromOrigin, -fVertexfromOrigin, 1.0f, 1.0f, -1.0f));
	normal = { 1.0f, -1.0f, -1.0f };
	meshCube->AddVertex(CVertex(fVertexfromOrigin, -fVertexfromOrigin, -fVertexfromOrigin, 1.0f, -1.0f, -1.0f));
	normal = { -1.0f, -1.0f, -1.0f };
	meshCube->AddVertex(CVertex(-fVertexfromOrigin, -fVertexfromOrigin, -fVertexfromOrigin, -1.0f, -1.0f, -1.0f));
	normal = { -1.0f, 1.0f, 1.0f };
	meshCube->AddVertex(CVertex(-fVertexfromOrigin, fVertexfromOrigin, fVertexfromOrigin, -1.0f, 1.0f, 1.0f));
	normal = { 1.0f, 1.0f, 1.0f };
	meshCube->AddVertex(CVertex(fVertexfromOrigin, fVertexfromOrigin, fVertexfromOrigin, 1.0f, 1.0f, 1.0f));
	normal = { 1.0f, -1.0f, 1.0f };
	meshCube->AddVertex(CVertex(fVertexfromOrigin, -fVertexfromOrigin, fVertexfromOrigin, 1.0f, -1.0f, 1.0f));
	normal = { -1.0f, -1.0f, 1.0f };
	meshCube->AddVertex(CVertex(-fVertexfromOrigin, -fVertexfromOrigin, fVertexfromOrigin, -1.0f, -1.0f, 1.0f));

	std::vector<int> vecIndices = { 0, 1, 3,
									1, 2, 3,
									1, 5, 2,
									5, 6, 2,
									5, 4, 6,
									4, 7, 6,
									4, 0, 7,
									0, 3, 7,
									4, 5, 0,
									5, 1, 0,
									3, 2, 7,
									2, 6, 7 };
	meshCube->AddIndices(vecIndices);

	meshCube->SetPrimitiveType(IGPT_TRIANGLELIST);
	meshCube->CreateStaticBuffer();
	return meshCube;
}

/***********************
* GetCamera: Retrieves the Games Camera
* @author: Callan Moore
* @return: CCamera*: The Games Camera
********************/
C3DObject CGame::CreateCube()
{
	// TO DO 
	return C3DObject();
}

/***********************
* GetCamera: Retrieves the Games Camera
* @author: Callan Moore
* @return: CCamera*: The Games Camera
********************/
CCamera* CGame::GetCamera()
{
	return m_pCamera;
}